/** `secretMask` dictionaries for the per-credential reveal control. */
/** Dictionary namespace owned by this plugin. */
export declare const NS = "secretMask";
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'secret.reveal': string;
    'secret.hide': string;
};
/** The secretMask namespace key union. */
export type SecretMaskKey = keyof typeof zh;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Accessible names of the control that reveals one masked credential. */
        secretMask: SecretMaskKey;
    }
}
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'secret.reveal': string;
    'secret.hide': string;
};
//# sourceMappingURL=locales.d.ts.map